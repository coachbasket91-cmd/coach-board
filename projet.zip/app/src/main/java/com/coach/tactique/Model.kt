package com.coach.tactique

import org.json.JSONArray
import org.json.JSONObject

const val N_TOKENS = 11
const val T_RUN = 0
const val T_PASS = 1
const val T_DRIBBLE = 2
const val T_SCREEN = 3

class Stroke(val type: Int) {
    val pts = ArrayList<Float>()
}

class Frame(val xs: FloatArray, val ys: FloatArray) {
    val strokes = ArrayList<Stroke>()
}

fun defaultFrame(): Frame {
    val ax = floatArrayOf(7.5f, 2.2f, 12.8f, 4.5f, 10.5f)
    val ay = floatArrayOf(10.5f, 7.5f, 7.5f, 4.2f, 4.2f)
    val xs = FloatArray(N_TOKENS)
    val ys = FloatArray(N_TOKENS)
    for (i in 0 until 5) {
        xs[i] = ax[i]
        ys[i] = ay[i]
        xs[5 + i] = ax[i]
        ys[5 + i] = ay[i] - 1.4f
    }
    xs[10] = 8.4f
    ys[10] = 10.2f
    return Frame(xs, ys)
}

class Project(var half: Boolean = true) {
    val frames = ArrayList<Frame>()

    init {
        frames.add(defaultFrame())
    }

    fun totalSeconds(): Float = (frames.size - 1) * (DWELL + MOVE) + DWELL_LAST

    // Remplit ox/oy avec les positions a l'instant t, renvoie l'etape dont on affiche les fleches
    fun stateAt(t0: Float, ox: FloatArray, oy: FloatArray): Int {
        var t = t0
        val n = frames.size
        for (i in 0 until n) {
            val f = frames[i]
            val dw = if (i == n - 1) DWELL_LAST else DWELL
            if (i == n - 1 || t < dw) {
                for (j in 0 until N_TOKENS) {
                    ox[j] = f.xs[j]
                    oy[j] = f.ys[j]
                }
                return i
            }
            t -= dw
            if (t < MOVE) {
                val k = t / MOVE
                val e = k * k * (3f - 2f * k)
                val g = frames[i + 1]
                for (j in 0 until N_TOKENS) {
                    ox[j] = f.xs[j] + (g.xs[j] - f.xs[j]) * e
                    oy[j] = f.ys[j] + (g.ys[j] - f.ys[j]) * e
                }
                return i
            }
            t -= MOVE
        }
        return n - 1
    }

    fun toJson(): String {
        val o = JSONObject()
        o.put("half", half)
        val fa = JSONArray()
        for (f in frames) {
            val fo = JSONObject()
            val xa = JSONArray()
            val ya = JSONArray()
            for (j in 0 until N_TOKENS) {
                xa.put(f.xs[j].toDouble())
                ya.put(f.ys[j].toDouble())
            }
            fo.put("x", xa)
            fo.put("y", ya)
            val sa = JSONArray()
            for (s in f.strokes) {
                val so = JSONObject()
                so.put("t", s.type)
                val pa = JSONArray()
                for (v in s.pts) pa.put(v.toDouble())
                so.put("p", pa)
                sa.put(so)
            }
            fo.put("s", sa)
            fa.put(fo)
        }
        o.put("frames", fa)
        return o.toString()
    }

    companion object {
        const val DWELL = 0.7f
        const val DWELL_LAST = 1.3f
        const val MOVE = 1.8f

        fun fromJson(str: String): Project {
            val o = JSONObject(str)
            val p = Project(o.getBoolean("half"))
            p.frames.clear()
            val fa = o.getJSONArray("frames")
            for (i in 0 until fa.length()) {
                val fo = fa.getJSONObject(i)
                val xa = fo.getJSONArray("x")
                val ya = fo.getJSONArray("y")
                val f = Frame(
                    FloatArray(N_TOKENS) { xa.getDouble(it).toFloat() },
                    FloatArray(N_TOKENS) { ya.getDouble(it).toFloat() }
                )
                val sa = fo.getJSONArray("s")
                for (k in 0 until sa.length()) {
                    val so = sa.getJSONObject(k)
                    val s = Stroke(so.getInt("t"))
                    val pa = so.getJSONArray("p")
                    for (m in 0 until pa.length()) s.pts.add(pa.getDouble(m).toFloat())
                    f.strokes.add(s)
                }
                p.frames.add(f)
            }
            if (p.frames.isEmpty()) p.frames.add(defaultFrame())
            return p
        }
    }
}
