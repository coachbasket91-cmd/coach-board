package com.coach.tactique

import android.content.Context
import android.graphics.Canvas
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View

class BoardView(ctx: Context) : View(ctx) {
    var project = Project()
    var current = 0
    var tool = 0 // 0 deplacer, 1 course, 2 passe, 3 dribble, 4 ecran
    var speed = 1f
    var playing = false
    var onChange: (() -> Unit)? = null

    private var playStart = 0L
    private var dragToken = -1
    private var curStroke: Stroke? = null
    private val tx = FloatArray(N_TOKENS)
    private val ty = FloatArray(N_TOKENS)

    fun play() {
        playing = true
        playStart = SystemClock.uptimeMillis()
        invalidate()
    }

    fun stop() {
        playing = false
        invalidate()
    }

    fun addStep() {
        val f = project.frames[current]
        project.frames.add(current + 1, Frame(f.xs.copyOf(), f.ys.copyOf()))
        current++
        invalidate()
    }

    fun deleteStep() {
        if (project.frames.size > 1) {
            project.frames.removeAt(current)
            if (current >= project.frames.size) current = project.frames.size - 1
            invalidate()
        }
    }

    fun undo() {
        val l = project.frames[current].strokes
        if (l.isNotEmpty()) l.removeAt(l.size - 1)
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val p = project
        if (current >= p.frames.size) current = p.frames.size - 1
        val w = width.toFloat()
        val h = height.toFloat()
        if (playing) {
            val t = (SystemClock.uptimeMillis() - playStart) / 1000f * speed
            if (t < p.totalSeconds()) {
                val sf = p.stateAt(t, tx, ty)
                Renderer.draw(c, w, h, p.half, tx, ty, p.frames[sf].strokes)
                postInvalidateOnAnimation()
                return
            }
            playing = false
            current = p.frames.size - 1
            post { onChange?.invoke() }
        }
        val f = p.frames[current]
        Renderer.draw(c, w, h, p.half, f.xs, f.ys, f.strokes)
    }

    private fun hit(f: Frame, x: Float, y: Float): Int {
        var best = -1
        var bd = 1.69f
        for (i in 0 until N_TOKENS) {
            val dx = f.xs[i] - x
            val dy = f.ys[i] - y
            val d = dx * dx + dy * dy
            if (d <= bd) {
                bd = d
                best = i
            }
        }
        return best
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (playing) return true
        val tr = Renderer.transform(width.toFloat(), height.toFloat(), project.half)
        val wx = (e.x - tr[1]) / tr[0] - Renderer.M
        val wy = (e.y - tr[2]) / tr[0] - Renderer.M
        val f = project.frames[current]
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                if (tool == 0) {
                    dragToken = hit(f, wx, wy)
                } else {
                    val s = Stroke(tool - 1)
                    s.pts.add(wx)
                    s.pts.add(wy)
                    f.strokes.add(s)
                    curStroke = s
                    invalidate()
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (tool == 0) {
                    if (dragToken >= 0) {
                        val minX = -Renderer.M + 0.4f
                        val maxX = Renderer.W + Renderer.M - 0.4f
                        val maxY = Renderer.worldH(project.half) + Renderer.M - 0.4f
                        f.xs[dragToken] = wx.coerceIn(minX, maxX)
                        f.ys[dragToken] = wy.coerceIn(minX, maxY)
                        invalidate()
                    }
                } else {
                    val s = curStroke
                    if (s != null) {
                        if (s.type == T_PASS || s.type == T_SCREEN) {
                            while (s.pts.size > 2) s.pts.removeAt(s.pts.size - 1)
                            s.pts.add(wx)
                            s.pts.add(wy)
                            invalidate()
                        } else {
                            val n = s.pts.size
                            val dx = wx - s.pts[n - 2]
                            val dy = wy - s.pts[n - 1]
                            if (dx * dx + dy * dy > 0.04f) {
                                s.pts.add(wx)
                                s.pts.add(wy)
                                invalidate()
                            }
                        }
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val s = curStroke
                if (s != null) {
                    val n = s.pts.size
                    val dx = s.pts[n - 2] - s.pts[0]
                    val dy = s.pts[n - 1] - s.pts[1]
                    if (n < 4 || dx * dx + dy * dy < 0.36f) f.strokes.remove(s)
                }
                curStroke = null
                dragToken = -1
                invalidate()
            }
        }
        return true
    }
}
