package com.coach.tactique

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import kotlin.math.hypot
import kotlin.math.min

object Renderer {
    const val W = 15f
    const val M = 1.6f

    private val floor = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFD9A760.toInt(); style = Paint.Style.FILL
    }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 0.08f
    }
    private val board = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF4E342E.toInt(); style = Paint.Style.STROKE; strokeWidth = 0.14f
    }
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFE65100.toInt(); style = Paint.Style.STROKE; strokeWidth = 0.07f
    }
    private val ink = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF111111.toInt(); style = Paint.Style.STROKE; strokeWidth = 0.11f
        strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val inkFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF111111.toInt(); style = Paint.Style.FILL
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 0.07f
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 0.72f; textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }
    private val rect = RectF()
    private val headPath = Path()

    fun worldH(half: Boolean): Float = if (half) 14f else 28f

    // [echelle, decalageX, decalageY]
    fun transform(vw: Float, vh: Float, half: Boolean): FloatArray {
        val s = min(vw / (W + 2 * M), vh / (worldH(half) + 2 * M))
        val ox = (vw - (W + 2 * M) * s) / 2f
        val oy = (vh - (worldH(half) + 2 * M) * s) / 2f
        return floatArrayOf(s, ox, oy)
    }

    fun draw(
        c: Canvas, vw: Float, vh: Float, half: Boolean,
        xs: FloatArray, ys: FloatArray, strokes: List<Stroke>
    ) {
        c.drawColor(0xFF1B2A30.toInt())
        val h = worldH(half)
        val tr = transform(vw, vh, half)
        c.save()
        c.translate(tr[1] + M * tr[0], tr[2] + M * tr[0])
        c.scale(tr[0], tr[0])
        c.drawRect(0f, 0f, W, h, floor)
        c.drawRect(0f, 0f, W, h, line)
        if (half) {
            drawHalf(c)
        } else {
            c.drawLine(0f, 14f, W, 14f, line)
            c.drawCircle(7.5f, 14f, 1.8f, line)
            drawHalf(c)
            c.save()
            c.rotate(180f, 7.5f, 14f)
            drawHalf(c)
            c.restore()
        }
        for (s in strokes) drawStroke(c, s)
        for (i in 0 until N_TOKENS) drawToken(c, i, xs[i], ys[i])
        c.restore()
    }

    private fun drawHalf(c: Canvas) {
        c.drawRect(5.05f, 0f, 9.95f, 5.8f, line)
        c.drawCircle(7.5f, 5.8f, 1.8f, line)
        rect.set(7.5f - 1.25f, 1.575f - 1.25f, 7.5f + 1.25f, 1.575f + 1.25f)
        c.drawArc(rect, 0f, 180f, false, line)
        c.drawLine(0.9f, 0f, 0.9f, 2.99f, line)
        c.drawLine(14.1f, 0f, 14.1f, 2.99f, line)
        rect.set(7.5f - 6.75f, 1.575f - 6.75f, 7.5f + 6.75f, 1.575f + 6.75f)
        c.drawArc(rect, 12.1f, 155.8f, false, line)
        c.drawLine(6.6f, 1.2f, 8.4f, 1.2f, board)
        c.drawCircle(7.5f, 1.575f, 0.225f, rim)
    }

    private fun drawToken(c: Canvas, i: Int, x: Float, y: Float) {
        if (i == 10) {
            fill.color = 0xFFFB8C00.toInt()
            c.drawCircle(x, y, 0.32f, fill)
            edge.color = 0xFF3E2723.toInt()
            c.drawCircle(x, y, 0.32f, edge)
            edge.color = Color.WHITE
            return
        }
        fill.color = if (i < 5) 0xFF1E88E5.toInt() else 0xFFE53935.toInt()
        c.drawCircle(x, y, 0.62f, fill)
        c.drawCircle(x, y, 0.62f, edge)
        val label = if (i < 5) "${i + 1}" else "X${i - 4}"
        val fm = textPaint.fontMetrics
        c.drawText(label, x, y - (fm.ascent + fm.descent) / 2f, textPaint)
    }

    private fun drawStroke(c: Canvas, s: Stroke) {
        val p = s.pts
        if (p.size < 4) return
        val n = p.size / 2
        val ex = p[p.size - 2]
        val ey = p[p.size - 1]
        var px = p[0]
        var py = p[1]
        var k = n - 2
        while (k >= 0) {
            val ax = ex - p[2 * k]
            val ay = ey - p[2 * k + 1]
            if (ax * ax + ay * ay > 0.36f) {
                px = p[2 * k]
                py = p[2 * k + 1]
                break
            }
            k--
        }
        var dx = ex - px
        var dy = ey - py
        val len = hypot(dx, dy)
        if (len < 0.001f) return
        dx /= len
        dy /= len
        val nx = -dy
        val ny = dx

        ink.pathEffect = if (s.type == T_PASS) DashPathEffect(floatArrayOf(0.45f, 0.3f), 0f) else null
        if (s.type == T_DRIBBLE) c.drawPath(zigzag(p, ex, ey), ink) else c.drawPath(smooth(p), ink)
        ink.pathEffect = null

        if (s.type == T_SCREEN) {
            c.drawLine(ex + nx * 0.65f, ey + ny * 0.65f, ex - nx * 0.65f, ey - ny * 0.65f, ink)
        } else {
            headPath.reset()
            headPath.moveTo(ex, ey)
            headPath.lineTo(ex - dx * 0.75f + nx * 0.35f, ey - dy * 0.75f + ny * 0.35f)
            headPath.lineTo(ex - dx * 0.75f - nx * 0.35f, ey - dy * 0.75f - ny * 0.35f)
            headPath.close()
            c.drawPath(headPath, inkFill)
        }
    }

    private fun smooth(p: List<Float>): Path {
        val path = Path()
        val n = p.size / 2
        path.moveTo(p[0], p[1])
        if (n == 2) {
            path.lineTo(p[2], p[3])
            return path
        }
        for (k in 1 until n - 1) {
            val mx = (p[2 * k] + p[2 * k + 2]) / 2f
            val my = (p[2 * k + 1] + p[2 * k + 3]) / 2f
            path.quadTo(p[2 * k], p[2 * k + 1], mx, my)
        }
        path.lineTo(p[2 * (n - 1)], p[2 * (n - 1) + 1])
        return path
    }

    private fun zigzag(p: List<Float>, ex: Float, ey: Float): Path {
        val q = resample(p, 0.5f)
        val path = Path()
        val n = q.size / 2
        path.moveTo(q[0], q[1])
        for (k in 1 until n) {
            var tx = q[2 * k] - q[2 * k - 2]
            var ty = q[2 * k + 1] - q[2 * k - 1]
            val l = hypot(tx, ty)
            if (l < 0.0001f) continue
            tx /= l
            ty /= l
            val sgn = if (k % 2 == 0) 1f else -1f
            path.lineTo(q[2 * k] - ty * 0.22f * sgn, q[2 * k + 1] + tx * 0.22f * sgn)
        }
        path.lineTo(ex, ey)
        return path
    }

    private fun resample(p: List<Float>, step: Float): ArrayList<Float> {
        val out = ArrayList<Float>()
        var px = p[0]
        var py = p[1]
        out.add(px)
        out.add(py)
        var need = step
        var i = 2
        while (i < p.size) {
            val qx = p[i]
            val qy = p[i + 1]
            var dx = qx - px
            var dy = qy - py
            var d = hypot(dx, dy)
            while (d >= need && d > 0f) {
                val t = need / d
                px += dx * t
                py += dy * t
                out.add(px)
                out.add(py)
                dx = qx - px
                dy = qy - py
                d = hypot(dx, dy)
                need = step
            }
            need -= d
            px = qx
            py = qy
            i += 2
        }
        return out
    }
}
