package com.coach.tactique

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {
    private lateinit var board: BoardView
    private lateinit var stepLabel: TextView
    private lateinit var playBtn: Button
    private lateinit var speedBtn: Button
    private lateinit var courtBtn: Button
    private val toolBtns = ArrayList<Button>()
    private val speeds = floatArrayOf(1f, 0.5f, 2f)
    private var speedIdx = 0
    private var name = "schema"

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun style(b: Button, on: Boolean) {
        val g = GradientDrawable()
        g.cornerRadius = dp(8).toFloat()
        g.setColor(if (on) 0xFF1E88E5.toInt() else 0xFF37474F.toInt())
        b.background = g
    }

    private fun btn(label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.setAllCaps(false)
        b.textSize = 12f
        b.setTextColor(0xFFFFFFFF.toInt())
        b.minWidth = 0
        b.minimumWidth = 0
        b.minHeight = 0
        b.minimumHeight = 0
        b.setPadding(dp(4), dp(9), dp(4), dp(9))
        style(b, false)
        b.setOnClickListener { onClick() }
        return b
    }

    private fun row(vararg v: View): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        for (x in v) {
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(dp(2), dp(2), dp(2), dp(2))
            r.addView(x, lp)
        }
        return r
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    private fun dir() = File(filesDir, "schemas")

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        board = BoardView(this)
        board.onChange = { refresh() }
        loadAuto()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(0xFF121212.toInt())
        root.addView(board, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val labels = arrayOf("Déplacer", "Course", "Passe", "Dribble", "Écran")
        for (i in labels.indices) {
            toolBtns.add(btn(labels[i]) {
                board.tool = i
                refresh()
            })
        }
        root.addView(row(*toolBtns.toTypedArray()))

        stepLabel = TextView(this)
        stepLabel.setTextColor(0xFFFFFFFF.toInt())
        stepLabel.textSize = 13f
        stepLabel.gravity = Gravity.CENTER
        root.addView(
            row(
                btn("◀") { stepTo(-1) },
                stepLabel,
                btn("▶") { stepTo(1) },
                btn("+ Étape") { board.stop(); board.addStep(); refresh() },
                btn("Suppr.") { board.stop(); board.deleteStep(); refresh() },
                btn("Annuler") { board.undo() }
            )
        )

        playBtn = btn("▶ Lecture") { togglePlay() }
        speedBtn = btn("Vitesse") {
            speedIdx = (speedIdx + 1) % speeds.size
            board.speed = speeds[speedIdx]
            refresh()
        }
        courtBtn = btn("Terrain") {
            confirm("Changer de terrain efface le schéma actuel. Continuer ?") {
                board.stop()
                board.project = Project(!board.project.half)
                board.current = 0
                board.invalidate()
                refresh()
            }
        }
        root.addView(row(playBtn, speedBtn, courtBtn, btn("Image") { exportImage() }, btn("Vidéo") { exportVideo() }))

        root.addView(
            row(
                btn("Nouveau") {
                    confirm("Effacer le schéma actuel ?") {
                        board.stop()
                        board.project = Project(board.project.half)
                        board.current = 0
                        board.invalidate()
                        refresh()
                    }
                },
                btn("Enregistrer") { saveDialog() },
                btn("Ouvrir") { openDialog() }
            )
        )

        setContentView(root)
        refresh()
    }

    override fun onPause() {
        super.onPause()
        board.stop()
        try {
            File(filesDir, "auto.json").writeText(board.project.toJson())
        } catch (e: Exception) { }
    }

    private fun loadAuto() {
        try {
            val f = File(filesDir, "auto.json")
            if (f.exists()) board.project = Project.fromJson(f.readText())
        } catch (e: Exception) { }
    }

    private fun refresh() {
        stepLabel.text = "Étape ${board.current + 1}/${board.project.frames.size}"
        playBtn.text = if (board.playing) "■ Stop" else "▶ Lecture"
        courtBtn.text = if (board.project.half) "Demi-terrain" else "Terrain entier"
        val sp = board.speed
        speedBtn.text = "Vitesse ×" + (if (sp == 0.5f) "0.5" else sp.toInt().toString())
        for (i in toolBtns.indices) style(toolBtns[i], i == board.tool)
    }

    private fun stepTo(d: Int) {
        board.stop()
        val n = board.current + d
        if (n >= 0 && n < board.project.frames.size) {
            board.current = n
            board.invalidate()
        }
        refresh()
    }

    private fun togglePlay() {
        if (board.playing) {
            board.stop()
        } else if (board.project.frames.size < 2) {
            toast("Ajoute au moins 2 étapes (bouton + Étape)")
        } else {
            board.play()
        }
        refresh()
    }

    private fun confirm(msg: String, ok: () -> Unit) {
        AlertDialog.Builder(this)
            .setMessage(msg)
            .setPositiveButton("Oui") { _, _ -> ok() }
            .setNegativeButton("Non", null)
            .show()
    }

    private fun saveDialog() {
        val et = EditText(this)
        et.setText(name)
        et.setSingleLine()
        AlertDialog.Builder(this)
            .setTitle("Nom du schéma")
            .setView(et)
            .setPositiveButton("Enregistrer") { _, _ ->
                val n = et.text.toString().trim().replace(Regex("[^A-Za-z0-9À-ÿ _-]"), "_")
                if (n.isNotEmpty()) {
                    name = n
                    dir().mkdirs()
                    File(dir(), "$n.json").writeText(board.project.toJson())
                    toast("Enregistré : $n")
                }
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun listFiles(): List<File> {
        val all = dir().listFiles() ?: emptyArray()
        return all.filter { it.name.endsWith(".json") }.sortedBy { it.name }
    }

    private fun openDialog() {
        val files = listFiles()
        if (files.isEmpty()) {
            toast("Aucun schéma enregistré")
            return
        }
        val names = files.map { it.name.removeSuffix(".json") }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Ouvrir")
            .setItems(names) { _, i ->
                try {
                    board.stop()
                    board.project = Project.fromJson(files[i].readText())
                    board.current = 0
                    name = names[i]
                    board.invalidate()
                    refresh()
                } catch (e: Exception) {
                    toast("Fichier illisible")
                }
            }
            .setNeutralButton("Supprimer…") { _, _ -> deleteDialog(files) }
            .setNegativeButton("Fermer", null)
            .show()
    }

    private fun deleteDialog(files: List<File>) {
        val names = files.map { it.name.removeSuffix(".json") }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Supprimer lequel ?")
            .setItems(names) { _, i ->
                files[i].delete()
                toast("Supprimé : ${names[i]}")
            }
            .setNegativeButton("Fermer", null)
            .show()
    }

    private fun shareDialog(uri: Uri?, mime: String, msg: String) {
        val b = AlertDialog.Builder(this).setMessage(msg).setNegativeButton("OK", null)
        if (uri != null) {
            b.setPositiveButton("Partager") { _, _ ->
                val it = Intent(Intent.ACTION_SEND)
                it.type = mime
                it.putExtra(Intent.EXTRA_STREAM, uri)
                it.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                startActivity(Intent.createChooser(it, "Partager"))
            }
        }
        b.show()
    }

    private fun exportImage() {
        board.stop()
        try {
            val f = File(cacheDir, "schema.png")
            Exporter.imageFile(board.project, board.current, f)
            val stamp = System.currentTimeMillis() / 1000
            val uri = Exporter.saveToGallery(
                this, f, "${name}_etape${board.current + 1}_$stamp.png",
                "image/png", "Pictures/TableauTactique", false
            )
            shareDialog(uri, "image/png", "Image enregistrée dans la galerie (dossier TableauTactique).")
        } catch (e: Exception) {
            toast("Erreur export image : ${e.message}")
        }
    }

    private fun exportVideo() {
        board.stop()
        if (board.project.frames.size < 2) {
            toast("Ajoute au moins 2 étapes pour faire une vidéo")
            return
        }
        val dlg = AlertDialog.Builder(this)
            .setMessage("Création de la vidéo… (quelques secondes)")
            .setCancelable(false)
            .show()
        val p = board.project
        val sp = board.speed
        val base = name
        Thread {
            var uri: Uri? = null
            var err: String? = null
            try {
                val f = File(cacheDir, "schema.mp4")
                Exporter.videoFile(p, sp, f)
                val stamp = System.currentTimeMillis() / 1000
                uri = Exporter.saveToGallery(
                    this, f, "${base}_$stamp.mp4",
                    "video/mp4", "Movies/TableauTactique", true
                )
            } catch (e: Exception) {
                err = e.message ?: e.toString()
            }
            runOnUiThread {
                dlg.dismiss()
                if (err != null) {
                    toast("Erreur export vidéo : $err")
                } else {
                    shareDialog(uri, "video/mp4", "Vidéo enregistrée dans la galerie (dossier TableauTactique).")
                }
            }
        }.start()
    }
}
