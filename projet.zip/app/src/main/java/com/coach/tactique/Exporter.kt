package com.coach.tactique

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.media.Image
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.provider.MediaStore
import java.io.File
import kotlin.math.ceil

object Exporter {
    fun videoSize(half: Boolean): Pair<Int, Int> = if (half) Pair(720, 672) else Pair(576, 1072)

    fun imageSize(half: Boolean): Pair<Int, Int> {
        val v = videoSize(half)
        return Pair(v.first * 3 / 2, v.second * 3 / 2)
    }

    fun imageFile(p: Project, frame: Int, out: File) {
        val (w, h) = imageSize(p.half)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val f = p.frames[frame]
        Renderer.draw(Canvas(bmp), w.toFloat(), h.toFloat(), p.half, f.xs, f.ys, f.strokes)
        out.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
    }

    fun saveToGallery(ctx: Context, src: File, displayName: String, mime: String, dir: String, video: Boolean): Uri? {
        val values = ContentValues()
        values.put(MediaStore.MediaColumns.DISPLAY_NAME, displayName)
        values.put(MediaStore.MediaColumns.MIME_TYPE, mime)
        values.put(MediaStore.MediaColumns.RELATIVE_PATH, dir)
        val collection = if (video) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        } else {
            MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        }
        val uri = ctx.contentResolver.insert(collection, values) ?: return null
        ctx.contentResolver.openOutputStream(uri)?.use { out ->
            src.inputStream().use { it.copyTo(out) }
        }
        return uri
    }

    private fun fillImage(img: Image, argb: IntArray, w: Int, h: Int) {
        val pl = img.planes
        val yb = pl[0].buffer
        val ub = pl[1].buffer
        val vb = pl[2].buffer
        val yr = pl[0].rowStride
        val yp = pl[0].pixelStride
        val ur = pl[1].rowStride
        val up = pl[1].pixelStride
        val vr = pl[2].rowStride
        val vp = pl[2].pixelStride
        for (j in 0 until h) {
            val rowOff = j * w
            for (i in 0 until w) {
                val px = argb[rowOff + i]
                val r = (px shr 16) and 0xFF
                val g = (px shr 8) and 0xFF
                val b = px and 0xFF
                val y = ((66 * r + 129 * g + 25 * b + 128) shr 8) + 16
                yb.put(j * yr + i * yp, y.toByte())
                if ((j and 1) == 0 && (i and 1) == 0) {
                    val u = ((-38 * r - 74 * g + 112 * b + 128) shr 8) + 128
                    val v = ((112 * r - 94 * g - 18 * b + 128) shr 8) + 128
                    ub.put((j shr 1) * ur + (i shr 1) * up, u.toByte())
                    vb.put((j shr 1) * vr + (i shr 1) * vp, v.toByte())
                }
            }
        }
    }

    fun videoFile(p: Project, speed: Float, out: File) {
        val (w, h) = videoSize(p.half)
        val fps = 30
        val total = ceil(p.totalSeconds() / speed * fps).toInt() + 1
        val fmt = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h)
        fmt.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
        fmt.setInteger(MediaFormat.KEY_BIT_RATE, 3_000_000)
        fmt.setInteger(MediaFormat.KEY_FRAME_RATE, fps)
        fmt.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        val codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        codec.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        codec.start()
        out.delete()
        val muxer = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var track = -1
        var started = false
        val info = MediaCodec.BufferInfo()
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val argb = IntArray(w * h)
        val tx = FloatArray(N_TOKENS)
        val ty = FloatArray(N_TOKENS)
        var frame = 0
        var inputDone = false
        var done = false
        try {
            while (!done) {
                if (!inputDone) {
                    val ii = codec.dequeueInputBuffer(10_000)
                    if (ii >= 0) {
                        val pts = frame * 1_000_000L / fps
                        if (frame >= total) {
                            codec.queueInputBuffer(ii, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            val t = frame.toFloat() / fps * speed
                            val sf = p.stateAt(t, tx, ty)
                            Renderer.draw(cv, w.toFloat(), h.toFloat(), p.half, tx, ty, p.frames[sf].strokes)
                            bmp.getPixels(argb, 0, w, 0, 0, w, h)
                            val img = codec.getInputImage(ii)
                            if (img != null) fillImage(img, argb, w, h)
                            codec.queueInputBuffer(ii, 0, w * h * 3 / 2, pts, 0)
                            frame++
                        }
                    }
                }
                val oi = codec.dequeueOutputBuffer(info, 10_000)
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    track = muxer.addTrack(codec.outputFormat)
                    muxer.start()
                    started = true
                } else if (oi >= 0) {
                    val buf = codec.getOutputBuffer(oi)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0
                    if (info.size > 0 && started && buf != null) {
                        buf.position(info.offset)
                        buf.limit(info.offset + info.size)
                        muxer.writeSampleData(track, buf, info)
                    }
                    codec.releaseOutputBuffer(oi, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) done = true
                }
            }
        } finally {
            try { codec.stop() } catch (e: Exception) { }
            codec.release()
            try { if (started) muxer.stop() } catch (e: Exception) { }
            muxer.release()
        }
    }
}
